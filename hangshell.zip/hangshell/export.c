//
// Created by 한광희 on 2017. 11. 26..
//

#include "prototype.h"
#include <string.h>
#include <stdlib.h>

extern char** environ;

void exportUsage(){
    printf("Usage. \n\texport name = value : set environ\n\texport : print environ\n\texport -d name(not $) : delete environ\n");
}

void printexport(){
    char** env;
    env = environ;
    while(*env){
        printf("%s\n", *env);
        env++;
    }
    return;
}

void addExport(char* name, char* value){
    setenv(name, value, 1);
    return;
}

void export(char** cline){
    char* val;
    if(cline[1] == NULL){
        printexport();
        return;
    }else if( strcmp(cline[1], "-d") == 0){
        if(cline[2] == NULL)
            exportUsage();
        unsetenv(cline[2]);
        return;
    }else if(cline [2] == NULL){
        printf("Usage : echo $NAME\n");
        return;
    }else if( strcmp(cline [2], "=\0") != 0){
        exportUsage();
        return;
    }else if(cline [3] == NULL){
        exportUsage();
        return;
    }else{
            printf("$%s = %s\n", cline[1], cline[3]);
            addExport(cline[1], cline[3]);
    }
}


//
// Created by on 2017. 11. 25..
//
#include "smallsh.h"

#ifndef UNTITLED5_PROTOTYPE_H
#define UNTITLED5_PROTOTYPE_H



/* mini_cmd */
int cd(char* path);
void signalHandler(int sig);
int fg(int jid);
void jobs();


/* ListControl */
pMybgList getLastNode(pMybgList head);
pMybgList initializeList();
pMybgList addList(int pid, char* name, pMybgList head, int status);
pMybgList findNodeByPid(int pid, pMybgList head);
pMybgList findNodeByJid(int jid, pMybgList head);
int deleteList(int pid, pMybgList head);
int getJid(pMybgList node, pMybgList head);
pMySetList findSetNodeByName(char* name, pMySetList head);
pMySetList getLastSetNode(pMySetList head);
pMySetList addSetList(char* name, pMySetList head, char* value);
pMySetList initializeSetList();
void printSetList();
void deleteAllSetNode(pMySetList head);
void deleteAllBgNode(pMybgList head);

/* set */
void set(char** cline);
void unset(char** cline);
int deleteSetList(char* name, pMySetList head);
void addSet(char* name, char* value);
void unSetList(char* name);
void printSet(char* name);
void setUsage();

/* echo */
void echo(char**);

/* main */
void signalHandler(int);
void signalHandler_cld(int sig);
void* sigProc(void* arg);
void reAndPipe(int direcType, char** arg, int narg, int type);

/* export */
void export(char** cline);
void addExport(char* name, char* value);
void printexport();
#endif //UNTITLED5_PROTOTYPE_H

/*Pipe Redirection*/
int redirection(int type, char *fileName);
int pipelining(char **command1, char **command2);
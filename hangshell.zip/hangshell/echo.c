//
// Created by 한광희 on 2017. 11. 26..
//

#include "prototype.h"
#include <stdlib.h>

/*echo로 환경변수나 쉘 변수를 치환한다 우선순위는 쉘변수 -> 환경 변수이다.
 *치환 방법은 $접두사를 검사하여 그후의 토큰을 name으로 리스트에 검색한다. 먄약 없다면 \t를 입력해 놓는다.*/

void echo(char** cline){
    int i = 1;
    char* val;
    while(cline[i]) {
        printf("%s", cline[i]);
        i++;
    }
    printf("\n");
    return;
}

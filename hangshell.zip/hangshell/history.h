

//
// Created by 이태형 on 2017. 11. 24..
//

#ifndef SYSTEMPROGRAMMING_HISTORY_H
#define SYSTEMPROGRAMMING_HISTORY_H

// 유저 홈 경로에 저장함
#define HISTORY_FILE_NAME "/.hangaram_history"

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <string.h>

/**
 * 초기화
 * @param stackSize : 히스토리 저장 메모리 크기 (이전 명령, 이후 명령 최대 저장수)
 * @param bufferSize : 명령어 버퍼 사이즈 (문장 길이)
 * @param historySize : 히스토리 저장 갯수 (초기 히스토리 로딩수, 출력수)
 * @return : 성공 0, 실패 -1
 */
int initHistory(int stackSize, int bufferSize, int historySize);


/**
 * 파괴
 * @return : 성공 0, 실패 -1
 */
int destroyHistory();

/**
 * 이전 임시 히스토리 (다음 히스토리에 자동 push됨)
 * @return : 명령어. 비어있으면 NULL
 */
char* popPrev();


/**
 * 다음 임시 히스토리 (이전 히스토리에 자동 push됨
 * @return : 명령어. 비어있으면 NULL
 */
char* popNext();


/**
 * 파일, 이전 임시 히스토리에 명령어 입력. (다음 히스토리에 자동 push됨)
 * @param command : 명령어
 */
void addHistory(char *command);


/**
 * 히스토리 점프 실행
 * @param idx : 실행할 히스토리 라인 번호
 * @return : 명령어. 없는경우 NULL
 */
char* getHistory(int idx);


void printHistory();

#endif //SYSTEMPROGRAMMING_HISTORY_H


//
// Created by 한광희 on 2017. 11. 26..
//

#include <string.h>
#include "prototype.h"

void setUsage(){
    printf("Usage.\n\tset : print set list\n\tset [name] : print set by name\n\tset [name] = [value] Set set.\n");
}
void unset(char** cline){
    if(cline[1] == NULL){
        printSetList();
        return;
    }else{
        unSetList(cline[1]);
    }
}

void set(char** cline){
    if(cline[1] == NULL){
        printSetList();
        return;
    }else if(cline [2] == NULL){
        //해당 이름의 변수 검색해 보여주기
        printSet(cline[1]);
        return;
    }else if( strcmp(cline [2], "=\0") != 0 ){
        setUsage();
    }else if(cline [3] == NULL){
        setUsage();
    }else{
        printf("$%s = %s\n",cline[1], cline[3]);
        addSet(cline[1], cline[3]);
    }
}


void printSetList(){
    pMySetList temp = setHead;

    printf("Set List. \n");
    while(temp != NULL){
        if(temp->name[0] == 0){
            temp = temp->Next;
            continue;
        }
        printf("$%s = %s\n", temp->name, temp->value);
        temp = temp->Next;
    }
}

void printSet(char* name){
    pMySetList temp = findSetNodeByName(name, setHead);
    if(temp != NULL){
        printf("$%s = %s\n", temp->name, temp->value);
    }
}

void addSet(char* name, char* value){
    pMySetList temp = findSetNodeByName(name, setHead);
    if(temp == NULL){
        addSetList(name, setHead, value);
    }else{
        strcpy(temp->value, value);
    }
    return;
}

void unSetList(char* name){
    if(deleteSetList(name, setHead) == -1){
        printf("[!]Failed unset.\n");
    }
    return;
}

//
// Created by 한광희 on 2017. 11. 25..
//

#include <stdlib.h>
#include <memory.h>
#include "smallsh.h"
#include "prototype.h"

/*
typedef struct _Mybg{
    char name[100];
    char jid;
    int  pid;
    struct _Mybg* Next;
    struct _Mybg* Prev;
}MybgList, *pMybgList;
*/



pMybgList initializeList(){
    pMybgList head = (pMybgList) malloc(sizeof(MybgList));
    head->name[0] = 0;
    head->Next = NULL;
    head->Prev = NULL;
    head->status = BGLIST_STATUS_HEAD;
    head->pid = 0;
    return head;
}

pMybgList addList(int pid, char* name, pMybgList head, int status){
    pMybgList node = (pMybgList) malloc(sizeof(MybgList));
    strcpy(node->name, name);
    node->Next = NULL;
    node->Prev = getLastNode(head);
    node->pid = pid;
    node->status = status;
    node->Prev->Next = node;

    return node;
}

pMybgList getLastNode(pMybgList head){
    pMybgList temp = head;

    while(temp != NULL){
        if(temp->Next != NULL) {
            temp = temp->Next;
            continue;
        }
        break;
    }
    return temp;
}

pMybgList findNodeByPid(int pid, pMybgList head){
    pMybgList temp = head;
    while(temp != NULL){
        if(temp->pid == pid){
            break;
        }
        temp = temp->Next;
    }
    return temp;
}


pMybgList findNodeByJid(int jid, pMybgList head){
    pMybgList temp = head;
    int j = 0;
    if(jid == 0){
        return NULL; //Head - failed
    }

    while(temp != NULL){
        if(jid == j){
            return temp;
        }
        j++;
        temp = temp->Next;
    }
    return NULL;
}

int deleteList(int pid, pMybgList head){
    pMybgList temp;
    temp = findNodeByPid(pid, head);
    if(temp == NULL){
        return -1;
    }

    if(temp->Prev == NULL){
        //is Head
        if(temp->Next == NULL){
            free(temp);
            return 0;       //리스트 모두 삭제
        }

        temp->Next->Prev = NULL;
        head = temp->Next;
        free(temp);
        return 0;
    }

    if(temp->Next == NULL){
        //is tail
        temp->Prev->Next = NULL;
        free(temp);
        return 0;
    }

    temp->Next->Prev = temp->Prev;
    temp->Prev->Next = temp->Next;
    free(temp);
    return 0;
}

int getJid(pMybgList node, pMybgList head){
    int jid = 0;
    pMybgList temp = head;

    while(temp != NULL){
        if(node->pid == temp->pid){
            return jid;
        }
        temp = temp->Next;
        jid++;
    }
    return -1;
}



//-------setList-----------


pMySetList initializeSetList(){
    pMySetList head = (pMySetList) malloc(sizeof(MySetList));
    head->name[0] = 0;
    head->value[0] = 0;
    head->Next = NULL;
    head->Prev = NULL;
    return head;
}


pMySetList addSetList(char* name, pMySetList head, char* value){
    pMySetList node = (pMySetList) malloc(sizeof(MySetList));
    strcpy(node->name, name);
    strcpy(node->value, value);
    node->Next = NULL;
    node->Prev = getLastSetNode(head);
    node->Prev->Next = node;
    return node;
}


pMySetList getLastSetNode(pMySetList head){
    pMySetList temp = head;

    while(temp != NULL){
        if(temp->Next != NULL) {
            temp = temp->Next;
            continue;
        }
        break;
    }
    return temp;
}


pMySetList findSetNodeByName(char* name, pMySetList head){
    pMySetList temp = head;
    if(name == NULL){
        return NULL; //Head - failed
    }

    while(temp != NULL){
        if( strcmp(name, temp->name) == 0){
            return temp;
        }
        temp = temp->Next;
    }
    return NULL;
}

int deleteSetList(char* name, pMySetList head){
    pMySetList temp;
    temp = findSetNodeByName(name, head);
    if(temp == NULL){
        return -1;
    }

    if(temp->Prev == NULL){
        //is Head
        if(temp->Next == NULL){
            free(temp);
            return 0;       //리스트 모두 삭제
        }

        temp->Next->Prev = NULL;
        head = temp->Next;
        free(temp);
        return 0;
    }

    if(temp->Next == NULL){
        //is tail
        temp->Prev->Next = NULL;
        free(temp);
        return 0;
    }

    temp->Next->Prev = temp->Prev;
    temp->Prev->Next = temp->Next;
    free(temp);
    return 0;
}

void deleteAllSetNode(pMySetList head){
    pMySetList temp = head;
    pMySetList preTemp;
    while(temp != NULL){
        preTemp = temp;
        temp = temp->Next;
        if(preTemp->name[0] != 0)
            printf("delet...set : %s\n", preTemp->name);
        free(preTemp);
    }
    printf("\n[*]Deleted! all set variables.\n");
}

void deleteAllBgNode(pMybgList head){
    pMybgList temp = head;
    pMybgList preTemp;
    while(temp != NULL){
        preTemp = temp;
        temp = temp->Next;
        if(preTemp->pid != 0)
            printf("Process exit...pid : %d\n", preTemp->pid);
        free(preTemp);
    }
    printf("\n[*]Exited! all background processes.\n");
}
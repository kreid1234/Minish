//
// Created by 이태형 on 2017. 11. 27..
//

#ifndef UNTITLED5_ALIAS_H
#define UNTITLED5_ALIAS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct _alias {
    char *key;
    char *value;
};

/**
 * 초기화
 * @param maxSize : 최대 앨리어스 수
 */
void initAlias(int maxSize);

/**
 * 파괴
 */
void destroyAlias();

/**
 * 앨리어스 추가/삭제
 * @param key : 앨리어스 키
 * @param value : 앨리어스 밸류
 * @return : 0:성공, -1:실패
 */
int setAlias(char *key, char *value);

/**
 * 키로 앨리어스 가져오기
 * @param key : 앨리어스 키 (명령어)
 * @return : _alias주소, NULL:없음
 */
struct _alias* getAlias(char *key);

/**
 * 앨리어스 제거
 * @param key : 제거할 앨리어스 키
 * @return : 0:성공 -1:실패
 */
int unAlias(char *key);

/**
 * 모든 앨리어스 출력
 */
void printAlias();

#endif //UNTITLED5_ALIAS_H

//
// Created by  on 2017. 11. 26..
//





#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include "smallsh.h"
#include "prototype.h"

void signalHandler(int sig){
    switch(sig){
        case SIGINT:
            if(c_proc.st_pid) {
                kill(c_proc.st_pid, SIGINT);
            }
            break;
        case SIGTSTP:

            if(c_proc.st_pid) {
                kill(c_proc.st_pid, SIGTSTP);
                pMybgList  added = addList(c_proc.st_pid, c_proc.fgName, head, BGLIST_STATUS_STOP);

                printf("\nStop. Pid : %d -> Jid : %d\n", c_proc.st_pid, getJid(added, head));
            }
            break;
    }
}

void signalHandler_cld(int sig){
    pid_t pid;
    while ( (pid = waitpid(-1, NULL, WNOHANG)) > 0) {
        sg_pid = pid;
        write(sig_fd[1], "g", 1);
    }

}

void* sigProc(void* arg){
    char status;
    pid_t pid;
    while(1){
        if(thread_exit_switch == 1) break;
        read(sig_fd[0], &status, 1);
        if(status == 'g'){
            pid = sg_pid;
            pMybgList t = findNodeByPid(pid, head);
            if (t != NULL) {
                t->status = BGLIST_STATUS_DONE;
                deleteList(pid, head);
                printf("\nDone.  Pid : %d\n", pid);
                //printf("%s",SHPROMPT);
                fflush(stdout);
            }
            status = 0;
        }
        usleep(1);
    }
    return (void*)0;
}
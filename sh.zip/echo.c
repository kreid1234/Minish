//
// Created by  on 2017. 11. 26..
//

#include "prototype.h"
#include <stdlib.h>


void echo(char** cline){
    int i = 1;
    char* val;
    while(cline[i]) {
        printf("%s", cline[i]);
        i++;
    }
    printf("\n");
    return;
}

//
// Created by  on 2017. 11. 27..
//

#include "alias.h"

struct _alias *aliasList;
int aliasCount;
int BUF_SIZE2 = 16;

int search(char *key) {
    for (int i = 0; i < aliasCount; i++)
        if (!strcmp(aliasList[i].key, key)) return i;

    return -1;
}

void initAlias(int bufSize) {
    BUF_SIZE2 = bufSize;
    aliasList = (struct _alias *) calloc(BUF_SIZE2, sizeof(struct _alias));


}

void destroyAlias() {
    for (int i = 0; i < aliasCount; i++) {
        free(aliasList[i].key);
        free(aliasList[i].value);
    }

    free(aliasList);
}

int setAlias(char *key, char *value) {
    int target = search(key);

    if (target == -1) { // add
        if (BUF_SIZE2 == aliasCount) return -1;

        struct _alias ali;
        ali.key = (char *) calloc((strlen(key)+1), sizeof(char));
        ali.value = (char *) calloc((strlen(value)+1), sizeof(char));
        strncpy(ali.key, key, strlen(key));
        ali.key[strlen(ali.key)] = '\n';
        strncpy(ali.value, value, strlen(value));
        ali.value[strlen(ali.value)] = '\n';

        aliasList[aliasCount++] = ali;
    }
    else { // update
        aliasList[target].value = (char *) realloc(aliasList[target].value, strlen(value) + 1);
        strncpy(aliasList[target].value, value, strlen(value) + 1);
    }

    return 0;
}

struct _alias* getAlias(char *key) {
    int target = search(key);

    if (target == -1) return NULL;

    return &aliasList[target];
}

int unAlias(char *originKey) {
    if (originKey == NULL) {
        for (int i = 0; i < aliasCount; i++) {
            free(aliasList[i].key);
            free(aliasList[i].value);
        }

        aliasCount = 0;
        return 0;
    }
    char *key = (char *) calloc(strlen(originKey) + 1, sizeof(char));
    strncpy(key, originKey, strlen(originKey));
    key = strcat(key, "\n");

    int target = search(key);

    if (target == -1) return -1;

    struct _alias ali = aliasList[target];
    free(ali.key);
    free(ali.value);
    --aliasCount;

    return 0;
}

void printAlias() {
    for (int i = 0; i < aliasCount; i++)
        printf("%s=%s\n", aliasList[i].key, aliasList[i].value);
}
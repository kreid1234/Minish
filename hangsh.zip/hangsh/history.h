

//
// Created by  on 2017. 11. 24..
//

#ifndef SYSTEMPROGRAMMING_HISTORY_H
#define SYSTEMPROGRAMMING_HISTORY_H


#define HISTORY_FILE_NAME "/.hangaram_history"

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <string.h>

int initHistory(int stackSize, int bufferSize, int historySize);


int destroyHistory();


char* popPrev();


char* popNext();


void addHistory(char *command);


char* getHistory(int idx);


void printHistory();

#endif //SYSTEMPROGRAMMING_HISTORY_H


//
// Created by  on 2017. 11. 26..
//



#include <fcntl.h>
#include <stdlib.h>
#include "smallsh.h"

int redirection(int type, char *fileName)
{
    int fd;
    int pFd;


    if (type == REDIRECTION_LEFT)
    {
        fd = open(fileName, O_RDONLY);

        pFd = dup(0);

        dup2(fd, 0);
    }


    else if (type == REDIRECTION_RIGHT || type == REDIRECTION_ADD)
    {

        if (type == REDIRECTION_RIGHT)
            fd = open(fileName, O_WRONLY | O_CREAT | O_TRUNC, 0744);


        else
        {
            fd = open(fileName, O_WRONLY | O_CREAT, 0744);
            lseek(fd, 0, SEEK_END);
        }

        pFd = dup(1);

        dup2(fd, 1);

    }

    close(fd);

    return pFd;
}

int pipelining(char **command1, char **command2)
{
    int p[2], status;

    switch (fork()) {
        case -1:
            perror("1st fork call in join");
            exit(1);
        case 0:
            break;
        default:
            wait(&status);
            return(status);
    }


    pipe(p);

    switch (fork()) {
        case -1:
            perror("2nd fork call in join");
            exit(1);

        case 0:
            dup2(p[1], 1);

            close(p[0]);
            close(p[1]);

            execvp(command1[0], command1);

            exit(1);

        default:
            dup2(p[0], 0);

            close(p[0]);
            close(p[1]);
            execvp(command2[0], command2);

            exit(1);
    }

}


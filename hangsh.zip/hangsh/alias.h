//
// Created by  on 2017. 11. 27..
//

#ifndef UNTITLED5_ALIAS_H
#define UNTITLED5_ALIAS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct _alias {
    char *key;
    char *value;
};

void initAlias(int maxSize);


void destroyAlias();


int setAlias(char *key, char *value);


struct _alias* getAlias(char *key);


int unAlias(char *key);


void printAlias();

#endif //UNTITLED5_ALIAS_H

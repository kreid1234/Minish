//
// Created by  on 2017. 11. 25..
//

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <memory.h>
#include "prototype.h"
#include "smallsh.h"

#define MAX_BUF 256


void jobs(){
    pMybgList temp = head;
    printf("[*] Job List.\n");
    char status[10] = {0,};
    for(; temp != NULL; temp = temp->Next){
        if(getJid(temp, head) != (int)NULL) {
            switch (temp->status) {
                case BGLIST_STATUS_STOP:
                    strcpy(status, "Stopped");
                    break;
                case BGLIST_STATUS_START:
                    strcpy(status, "Started");
                    break;
                case BGLIST_STATUS_DONE:
                    strcpy(status, "Done");
                    break;
            }
            if(status[0] != (char)NULL) {
                printf("[%d]\t%s\t\t%s\n", getJid(temp, head), status, temp->name);
            }
        }
    }

}

int fg(int jid){
    int status;
    int pid;
    char name[100] = {0,};
    pMybgList targetNode = findNodeByJid(jid, head);
    if(targetNode == NULL) return 0;
    pid = targetNode->pid;
    if(targetNode->status == BGLIST_STATUS_STOP) {
        kill(pid, SIGCONT);
    }
    strcpy(name, targetNode->name);
    deleteList(pid, head);

    c_proc.st_pid = pid;
    strcpy(c_proc.fgName, name);
    if (waitpid(pid, &status, WUNTRACED) == -1) {
        c_proc.fgName[0] = (char)NULL;
        c_proc.st_pid = 0;
        return -1;
    }else{
        c_proc.fgName[0] = (char)NULL;
        c_proc.st_pid = 0;
        return status;
    }
}

int cd(char* path){

    static char* prevPath[MAX_BUF] = {0,};

    /*Init*/
    if(prevPath[1] == NULL) {
        getcwd(prevPath, MAX_BUF);
    }

    if(path == NULL || *path == '~'){
        if(chdir(getenv("HOME"))){
            return -1;
        }
        printf("%s\n", getcwd(0, MAX_BUF));

        return 0;

    }else if(*path == '-'){
        if(chdir((const char*)prevPath)){
            return -1;
        }
        printf("%s\n", getcwd(0, MAX_BUF));
        return 0;
    }

    if(chdir(path)){
        return -1;
    }

    printf("%s\n", getcwd(0, MAX_BUF));
    return 0;

}

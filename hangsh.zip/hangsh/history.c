//
// Created by on 2017. 11. 26..
//

#include <memory.h>
#include "history.h"

int fd = -1;
char *path;
char **prevStack;
char **nextStack;
int stackCap;
int prevStackIdx;
int nextStackIdx;
int BUF_SIZE = 512;

int HISTORY_BUF_SIZE = 100;
char **history;
int historyLength;
void pushPrev(char *command) {
    char *buf;
    if (prevStackIdx == stackCap-1) {
        buf = prevStack[0];
        memcpy(prevStack, prevStack + 1, (stackCap - 1) * sizeof(char**));
        prevStack[prevStackIdx] = buf;

        strncpy(prevStack[prevStackIdx], command, strlen(command));
    }
    else
        strncpy(prevStack[prevStackIdx++], command, strlen(command));
}

void pushNext(char *command) {
    char *buf;
    if (nextStackIdx == stackCap-1) {
        buf = nextStack[0];
        memcpy(nextStack, nextStack + 1, (stackCap - 1) * sizeof(char**));
        nextStack[nextStackIdx] = buf;

        strncpy(nextStack[nextStackIdx], command, strlen(command));
    }
    else
        strncpy(nextStack[nextStackIdx++], command, strlen(command));
}
char* popPrev() {
    if (prevStackIdx == 0) return NULL;
    char *command = prevStack[(prevStackIdx--) - 1];
    pushNext(command);

    return command;
}

char* popNext() {
    if (nextStackIdx == 0) return NULL;
    char *command = nextStack[(nextStackIdx--) - 1];
    pushPrev(command);

    return command;
}

//
void getPw(struct passwd **pw) {
    uid_t uid = getuid();
    *pw = getpwuid(uid);
}

int getHistoryFile(struct passwd *pw, char *buffer, int bufferSize) {
    char tempBuf[bufferSize];
    char *dir = pw->pw_dir;
    char *name = HISTORY_FILE_NAME;

    if (strlen(dir) + strlen(name) > bufferSize) return -1;

    memset(buffer, 0x0, bufferSize);
    memset(tempBuf, 0x0, bufferSize);
    strncat(tempBuf, dir, strlen(pw->pw_dir));
    strncat(tempBuf, name, strlen(HISTORY_FILE_NAME));
    strncpy(buffer, tempBuf, strlen(tempBuf));

    return 0;
}

int initHistory(int stackSize, int bufferSize, int historySize) {
    int code = 0;
    struct passwd *pw;
    getPw(&pw);

    path = (char *) malloc(bufferSize);
    stackCap = stackSize;
    BUF_SIZE = bufferSize;
    HISTORY_BUF_SIZE = historySize;
    historyLength = 0;

    if (getHistoryFile(pw, path, BUF_SIZE) < 0)
        code = -1;
    if (code == 0 && (fd = open(path, O_RDWR | O_APPEND | O_CREAT, 0755)) < 0)
        code = -1;

    if (code == 0) {
        prevStack = (char **) calloc(stackSize, sizeof(char*));
        nextStack = (char **) calloc(stackSize, sizeof(char*));

        for (int i = 0; i < stackSize; i++) {
            prevStack[i] = (char *) calloc(bufferSize, sizeof(char));
            nextStack[i] = (char *) calloc(bufferSize, sizeof(char));
            prevStackIdx = 0;
            nextStackIdx = 0;
        }
    }

    history = (char **) calloc(historySize, sizeof(char *));
    for (int i = 0; i < historySize; i++)
        history[i] = (char *) calloc(bufferSize, sizeof(char));

    int re = loadHistory(historySize);

    return code;
}

int destroyHistory() {
    if (fd < 0) return 0;

    int code = close(fd);
    if (code > -1) {
        free(path);

        for (int i = 0; i < stackCap; i++) {
            free(prevStack[i]);
            free(nextStack[i]);
        }

        free(prevStack);
        free(nextStack);

        for (int i = 0; i < HISTORY_BUF_SIZE; i++)
            free(history[i]);

        free(history);
    }

    return code;
}
void addHistory(char *lineArg) {
    char line[BUF_SIZE];
    strncpy(line, lineArg, strlen(lineArg));
    char *temp;

    write(fd, line, strlen(line));

    if (historyLength == HISTORY_BUF_SIZE) {
        temp = history[0];
        memcpy(history, history + 1, sizeof(char **) * (HISTORY_BUF_SIZE - 1));
        history[HISTORY_BUF_SIZE-1] = temp;
        strncpy(history[historyLength-1], line, strlen(line));
    }
    else
        strncpy(history[historyLength++], line, strlen(line));
    pushPrev(line);
}

int loadHistory(int count) {
    char chunk;
    char buf[BUF_SIZE];
    off_t currentOff;
    int strLength = 0;

    currentOff = lseek(fd, (off_t) -2, SEEK_END);
    memset(buf, 0x0, BUF_SIZE);

    for (ssize_t code; historyLength < count; currentOff = lseek(fd, (off_t) -2, SEEK_CUR)) {
        code = read(fd, &chunk, 1);
        if (code > 0) {
            if (chunk != '\n') {
                if (currentOff == 0) {
                    ++strLength;
                    lseek(fd, (off_t) -1, SEEK_CUR);
                    read(fd, history[historyLength++], strLength + 1);
                    lseek(fd, (off_t) (-(strLength)), SEEK_CUR);
                    break;
                }

                ++strLength;
            } else {
                lseek(fd, (off_t) 0, SEEK_CUR);
                read(fd, history[historyLength++], strLength + 1);
                lseek(fd, (off_t) (-(strLength + 1)), SEEK_CUR);
                strLength = 0;
            }
        }
        else return -1;
    }

    for (int i = 0; i < (historyLength / 2); i++) {
        char *temp = history[i];

        history[i] = history[(historyLength-1) - i];
        history[(historyLength-1) - i] = temp;
    }
    return 0;

}

void printHistory() {
    for (int i = 0; i < historyLength; i++)
        printf("%d: %s", i, history[i]);
    printf("\n");
}

char* getHistory(int idx) {
    if (idx < 0 || idx > historyLength-1) return NULL;

    history[idx][strlen(history[idx])] = '\0';
    return history[idx];
}
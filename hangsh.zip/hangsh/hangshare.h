//
// Created by 이태형 on 2017. 11. 27..
//

#ifndef UNTITLED5_HANGFSTREAM_H
#define UNTITLED5_HANGFSTREAM_H

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include </usr/include/sys/socket.h>
#include <netinet/in.h>
#include <pthread/pthread.h>
#include <arpa/inet.h>

int startSharing(int bufSize, char *file);

#endif //UNTITLED5_HANGFSTREAM_H

/* smallsh.h -- definitions for smallsh command processor */

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#ifndef UNTITLED5_SMALLSH_H
#define UNTITLED5_SMALLSH_H

#define SHPROMPT "Hangshell _> "
#define COMMANDNUM 13



#define EOL        1               /* end of line */
#define ARG        2               /* normal argument */
#define AMPERSAND  3
#define SEMICOLON  4
#define MAXARG     512       /* max. no. command args */
#define MAXBUF     512       /* max. length input line */
#define FOREGROUND 0
#define BACKGROUND 1
#define REDIRECTION_LEFT    5
#define REDIRECTION_RIGHT   6
#define REDIRECTION_ADD     8
#define PIPE                7




/*  내장 명령   */
#define MINICMD_CD      0
#define MINICMD_JOBS    1
#define MINICMD_EXIT    2
#define MINICMD_FG      3
#define MINICMD_HISTORY 4
#define MINICMD_SET     5
#define MINICMD_UNSET   6
#define MINICMD_EXPORT  7
#define MINICMD_HELP    8
#define MINICMD_HIS     9


#define MINICMD_ALIAS 10
#define MINICMD_UNALIAS 11
#define MINICMD_SHARE 12


#define BGLIST_STATUS_START 0
#define BGLIST_STATUS_STOP  1
#define BGLIST_STATUS_DONE  2
#define BGLIST_STATUS_HEAD  3



/*Struct*/
#pragma pack(push, 1)

typedef struct _Mybg{
    char name[100];
    int  pid;
    int  status;
    struct _Mybg* Next;
    struct _Mybg* Prev;
}MybgList, *pMybgList;

typedef struct _MySet{
    char name[100];
    char value[100];
    struct _MySet* Next;
    struct _MySet* Prev;
}MySetList, *pMySetList;

typedef struct _currentProc{
    char fgName[100];
    int st_pid;
}stCurrentProc;

#pragma pack(pop)

/* extern */
extern pMySetList setHead;
extern pMybgList head;
extern stCurrentProc c_proc;
extern pthread_t thread_t;
extern pid_t sg_pid;
extern char* shellval[100];
extern int sig_fd[2];
extern int thread_status;
extern int thread_exit_switch;
#endif